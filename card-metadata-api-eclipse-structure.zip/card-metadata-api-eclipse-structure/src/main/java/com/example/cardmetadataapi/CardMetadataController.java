package com.example.cardmetadataapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;

@RestController
public class CardMetadataController {

    private static final List<CardMetadata> CARD_METADATA_LIST = Arrays.asList(
        new CardMetadata("MASTERCARD", "Debit", "ICICI Bank", "India", true, "5555555555554444", "123", "12/25", "John"),
        new CardMetadata("VISA", "Credit", "HDFC Bank", "India", false, "4111111111111111", "456", "11/24", "Jane"),
        new CardMetadata("RUPAY", "Debit", "SBI", "India", true, "6075000000000000", "789", "10/26", "Rahul"),
        new CardMetadata("AMEX", "Credit", "American Express", "USA", false, "378282246310005", "159", "09/23", "Emily"),
        new CardMetadata("DISCOVER", "Credit", "Discover Bank", "USA", false, "6011111111111117", "753", "08/27", "Michael")
    );

    @GetMapping("/carddetails/{cardNumber}")
    public CardMetadata getCardDetails(@PathVariable String cardNumber) {
        return CARD_METADATA_LIST.stream()
                .filter(card -> card.getCardNumber().equals(cardNumber))
                .findFirst()
                .orElse(null);
    }

    @GetMapping("/carddetails")
    public List<CardMetadata> getAllCardDetails() {
        return CARD_METADATA_LIST;
    }
}
