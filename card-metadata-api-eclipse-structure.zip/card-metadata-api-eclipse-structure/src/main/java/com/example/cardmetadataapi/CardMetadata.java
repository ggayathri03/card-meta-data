
package com.example.cardmetadataapi;

public class CardMetadata {
    private String cardScheme;
    private String cardType;
    private String issuer;
    private String country;
    private boolean prepaid;
    private String cardNumber;
    private String cvv;
    private String expiryDate;
    private String cardHolderName;  // New field

    public CardMetadata(String cardScheme, String cardType, String issuer, String country,
                        boolean prepaid, String cardNumber, String cvv, String expiryDate,
                        String cardHolderName) {
        this.cardScheme = cardScheme;
        this.cardType = cardType;
        this.issuer = issuer;
        this.country = country;
        this.prepaid = prepaid;
        this.cardNumber = cardNumber;
        this.cvv = cvv;
        this.expiryDate = expiryDate;
        this.cardHolderName = cardHolderName; // initialize
    }

    // Getters and setters

    public String getCardScheme() { return cardScheme; }
    public void setCardScheme(String cardScheme) { this.cardScheme = cardScheme; }

    public String getCardType() { return cardType; }
    public void setCardType(String cardType) { this.cardType = cardType; }

    public String getIssuer() { return issuer; }
    public void setIssuer(String issuer) { this.issuer = issuer; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public boolean isPrepaid() { return prepaid; }
    public void setPrepaid(boolean prepaid) { this.prepaid = prepaid; }

    public String getCardNumber() { return cardNumber; }
    public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }

    public String getCvv() { return cvv; }
    public void setCvv(String cvv) { this.cvv = cvv; }

    public String getExpiryDate() { return expiryDate; }
    public void setExpiryDate(String expiryDate) { this.expiryDate = expiryDate; }

    public String getCardHolderName() { return cardHolderName; }
    public void setCardHolderName(String cardHolderName) { this.cardHolderName = cardHolderName; }
}
